
function atualizarNome() {
  
  let nome = document.getElementById('novoNome').value; 
  document.getElementById('resultado').textContent = "Nome atual: " + nome;

  document.getElementById('cadastroForm').reset();
}
    